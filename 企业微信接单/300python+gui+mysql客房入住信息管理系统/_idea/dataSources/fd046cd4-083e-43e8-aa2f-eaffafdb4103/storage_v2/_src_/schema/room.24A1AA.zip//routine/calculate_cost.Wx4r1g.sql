create
    definer = root@localhost procedure calculate_cost(IN start_date date, IN end_date date)
BEGIN
    SELECT rt.type_name, SUM(DATEDIFF(ci.check_out_date, ci.check_in_date)) AS total_days, SUM(rp.price * DATEDIFF(ci.check_out_date, ci.check_in_date)) AS total_cost
    FROM customer_info ci
             JOIN room_info ri ON ci.room_id = ri.room_id
             JOIN room_type rt ON ri.type_id = rt.type_id
             JOIN room_price rp ON rt.type_id = rp.type_id AND ci.check_in_date >= rp.start_date AND ci.check_out_date <= rp.end_date
    WHERE (ci.check_in_date BETWEEN start_date AND end_date) OR (ci.check_out_date BETWEEN start_date AND end_date)
    GROUP BY rt.type_name;
END;

