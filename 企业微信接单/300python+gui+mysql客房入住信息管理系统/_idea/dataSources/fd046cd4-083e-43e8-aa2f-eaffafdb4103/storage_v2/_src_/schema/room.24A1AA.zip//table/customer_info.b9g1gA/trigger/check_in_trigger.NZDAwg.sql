create definer = root@localhost trigger check_in_trigger
    after insert
    on customer_info
    for each row
BEGIN
    UPDATE room_info SET status = 'Occupied' WHERE room_id = NEW.room_id;
END;

