create definer = root@localhost trigger check_out_trigger
    after update
    on customer_info
    for each row
BEGIN
    IF NEW.check_out_date IS NOT NULL THEN
        UPDATE room_info SET status = 'Vacant' WHERE room_id = NEW.room_id;
    END IF;
END;

