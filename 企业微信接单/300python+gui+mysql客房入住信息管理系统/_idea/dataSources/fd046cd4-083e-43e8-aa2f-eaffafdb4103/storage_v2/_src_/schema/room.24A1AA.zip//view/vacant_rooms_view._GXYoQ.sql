create definer = root@localhost view vacant_rooms_view as
select `ri`.`room_id` AS `room_id`, `ri`.`room_number` AS `room_number`, `rt`.`type_name` AS `type_name`
from (`room`.`room_info` `ri` join `room`.`room_type` `rt` on ((`ri`.`type_id` = `rt`.`type_id`)))
where (`ri`.`status` = 'Vacant');

