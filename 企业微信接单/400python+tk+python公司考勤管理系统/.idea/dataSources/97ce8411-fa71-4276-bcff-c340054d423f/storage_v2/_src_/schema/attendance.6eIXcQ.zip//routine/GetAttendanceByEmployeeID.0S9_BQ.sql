create
    definer = root@localhost procedure GetAttendanceByEmployeeID(IN empID int)
BEGIN
  SELECT *
  FROM Attendance
  WHERE EmployeeID = empID;
END;

