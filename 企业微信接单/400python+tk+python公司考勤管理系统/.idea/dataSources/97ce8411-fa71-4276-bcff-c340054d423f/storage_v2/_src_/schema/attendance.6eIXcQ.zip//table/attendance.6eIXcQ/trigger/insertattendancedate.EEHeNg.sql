create definer = root@localhost trigger InsertAttendanceDate
    before insert
    on attendance
    for each row
BEGIN
  SET NEW.Date = CURDATE();
END;

