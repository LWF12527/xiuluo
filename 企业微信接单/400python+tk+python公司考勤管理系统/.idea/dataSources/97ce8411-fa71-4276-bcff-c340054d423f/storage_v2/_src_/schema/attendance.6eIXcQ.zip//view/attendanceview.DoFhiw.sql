create definer = root@localhost view attendanceview as
select `a`.`AttendanceID`     AS `AttendanceID`,
       `a`.`Date`             AS `Date`,
       `a`.`AttendanceTypeID` AS `AttendanceTypeID`,
       `a`.`EmployeeID`       AS `EmployeeID`,
       `e`.`Name`             AS `Name`,
       `e`.`Department`       AS `Department`,
       `e`.`Position`         AS `Position`
from (`attendance`.`attendance` `a` join `attendance`.`employee` `e` on ((`a`.`EmployeeID` = `e`.`EmployeeID`)));

